Tiltmeter: Applied Geomechanics (analog)
Latitude: 19.4209
Longitude: -155.2909
Instrument Depth: 5.25 meters

Translation equation applied for X-Y to E-N tilt: 
Etilt = (cos(Az)*cX*Xtilt)+(sin(Az)*cY*Ytilt)
Ntilt = (-sin(Az)*cX*Xtilt)+(cos(Az)*cY*Ytilt)
cX=48.2, cY=48.2, Az=0 degrees


UWE_20180430T000000-20180805T000000.csv:
The tiltmeter’s X-tilt sensor went off-scale on May 12, 2018. After this time only data from the Y-tilt sensor are available.  Starting on July 16, the Y-tilt sensor began to go off-scale just before collapse events, by July 20 this component was largely off-scale as well.  Data is also available from tiltmeter UWD which was installed in the same borehole as UWE and provides a more complete view of tilt at this location.
