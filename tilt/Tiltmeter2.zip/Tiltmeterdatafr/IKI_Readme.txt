Tiltmeter: Applied Geomechanics (analog)
Latitude: 19.4191
Longitude: -155.2458
Instrument Depth: #.# meters

Translation equation applied for X-Y to E-N tilt: 
Etilt = (cos(Az)*cX*Xtilt)+(sin(Az)*cY*Ytilt)
Ntilt = (-sin(Az)*cX*Xtilt)+(cos(Az)*cY*Ytilt)
cX=49.9, cY=50, Az=0 degrees


IKI_20180430T000000-20180620T033700.csv:
This file contains data gaps that are due to outages of hour to days, especially towards the end of the timespan.  The file ends at the beginning of an extended data outage due to a bad datalogger.

IKI_20180726T065000-20180805T000000.csv:
Station was brought back online after changing the datalogger.  No changes to the tiltmeter at this time.

