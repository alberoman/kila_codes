Tiltmeter: Applied Geomechanics LILY (digital)
Latitude:  19.3905
Longitude: -155.2937
Instrument Depth: 5.5 meters

Translation equation applied for X-Y to E-N tilt: 
Etilt = (cos(Az)*cX*Xtilt)+(sin(Az)*cY*Ytilt)
Ntilt = (-sin(Az)*cX*Xtilt)+(cos(Az)*cY*Ytilt)
cX=1, cY=1, Az=0 degrees


SDH_20180430T000000-20180523T030900.csv:

SDH_20180523T031000-20180624T201700.csv:
Tiltmeter was releveled on May 23, it then continued to collect data until May 25 at which time the station lost power and telemetry due to ash deposits covering the solar panels. Crews visited the site to clean the panels after the period of large ashy explosions, on June 8.  No data is available from May 25 - May 31, Auxiliarly data only is present from May 31 - June 8.

SDH_20180624T201800-20180805T000000.csv:
Tiltmeter was releveled on June 24, no other changes at this time.
