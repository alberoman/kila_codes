Tiltmeter: Applied Geomechanics LILY (digital)
Latitude: 19.4209
Longitude: -155.2909
Instrument Depth: 4 meters

Translation equation applied for X-Y to E-N tilt: 
Etilt = (cos(Az)*cX*Xtilt)+(sin(Az)*cY*Ytilt)
Ntilt = (-sin(Az)*cX*Xtilt)+(cos(Az)*cY*Ytilt)
cX=1, cY=1, Az=0 degrees


UWD_20180430T000000-20180520T193000.csv:
Contains natively 1-minute sampled tiltmeter data and auxiliary data

UWD_20180520T193000-20180702T040400.csv:
Tiltmeter was reprogrammed to collect data natively at 1 second sample rate.  This file contains 1 minute averages of the raw 1 second data

UWD_20180702T040400-20180806T000000.csv:
Tiltmeter was releveled on 7/2/2018, no other changes at this time.
Estimated: Xoff=326 mrad  Yoff=-310 mrad
